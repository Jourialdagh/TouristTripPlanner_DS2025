function planTrip() {
    let country = document.getElementById("country").value;
    let interests = document.getElementById("interests").value.split(",").map(i => i.trim().toLowerCase());
    let destinations = parseInt(document.getElementById("destinations").value);
    let speed = document.getElementById("speed").value;
    let budget = parseInt(document.getElementById("budget").value);

    const categoryIcons = {
        "nature": "🏞️",
        "history": "🏛️",
        "entertainment": "🎭",
        "landmark": "📍",
        "restaurant": "🍴"
    };

    const sampleCities = {
        "Saudi Arabia": [
            { name: "Riyadh Boulevard", category: "Entertainment", time: 2, cost: 100 },
            { name: "Masmak Fortress", category: "History", time: 2, cost: 100 },
            { name: "Edge of the World", category: "Nature", time: 4, cost: 50 },
            { name: "Al Nakheel Restaurant", category: "Restaurant" }
        ],
        "Japan": [
            { name: "Tokyo Tower", category: "Landmark", time: 2, cost: 60 },
            { name: "Meiji Shrine", category: "History", time: 2, cost: 45 },
            { name: "Akihabara", category: "Entertainment", time: 2, cost: 200 },
            { name: "Sushi Dai", category: "Restaurant" }
        ],
        "Austria": [
            { name: "Schönbrunn Palace", category: "History", time: 3, cost: 200 },
            { name: "Hallstatt Village", category: "Nature", time: 3, cost: 300 },
            { name: "Plachutta Restaurant", category: "Restaurant" }
        ]
    };

    let places = sampleCities[country];
    let matched = [];

    for (let p of places) {
        if (p.category === "Restaurant" || interests.includes(p.category.toLowerCase())) {
            matched.push(p);
        }
    }

    let output = "";
    let route = [];
    let totalHours = 0;
    let totalCost = 0;

    output += `<h3>📅 Day-by-Day Itinerary</h3>`;
    let day = 1;

    for (let i = 0; i < Math.min(destinations, matched.length); i++) {
        if (i % 3 === 0) {
            output += `<h4>🗓️ Day ${day++}</h4>`;
        }

        let p = matched[i];
        let icon = categoryIcons[p.category.toLowerCase()] || "📌";
        output += `<div class="attraction-card">${icon} <strong>${p.name}</strong> (${p.category})`;

        if (p.time) {
            output += ` – ${p.time} hrs, $${p.cost}`;
            totalHours += p.time;
            totalCost += p.cost;
            route.push(p.name);
        }

        output += `</div>`;
    }

    if (route.length > 1) {
        output += `<p><strong>📍 Suggested Route:</strong> ${route.join(" → ")}</p>`;
    }

    let hoursPerDay = speed === "Relaxed" ? 4 : speed === "Moderate" ? 6 : 8;
    let days = Math.ceil(totalHours / hoursPerDay);

    output += `<p><strong>⏱️ Total Time:</strong> ${totalHours} hours</p>`;
    output += `<p><strong>📆 Days Needed:</strong> ${days} day(s)</p>`;
    output += `<p><strong>💰 Total Cost:</strong> $${totalCost}</p>`;

    if (budget > 0) {
        if (totalCost <= budget) {
            output += `<p style="color:green;">✔️ You're within budget!</p>`;
        } else {
            output += `<p style="color:red;">❌ You exceed your budget by $${totalCost - budget}</p>`;
        }
    }

    let mapLink = "https://www.google.com/maps/dir/" + route.map(r => encodeURIComponent(r)).join("/");
    output += `<p><a href="${mapLink}" target="_blank">🗺️ View in Google Maps</a></p>`;

    document.getElementById("tripOutput").innerHTML = output;
}
